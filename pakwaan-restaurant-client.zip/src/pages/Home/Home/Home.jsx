import { Banner } from "../Banner/Banner"
import { Catagory } from "./Catagory/Catagory"


export const Home = () => {
  return (
  <>
  <Banner></Banner>
  <Catagory></Catagory>
  
  </>
  )
}
